<?php
$a = "frank";
echo "<br>";
echo $a;
?>
